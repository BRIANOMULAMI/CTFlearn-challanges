package androidx.lifecycle.livedata.core;

public final class R {
    private R() {
    }
}
